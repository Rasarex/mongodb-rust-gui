export MONGODB_URI='mongodb://superUser:12345@localhost:27017/?authSource=wypozyczalnia'
mongo < bootstrap.js;